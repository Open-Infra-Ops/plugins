"""Do hook"""

def new_func(origin_cls, method_name, signature=None,
             source=False, *args, **kwargs):
    """Do new_func"""

    copyNewClass = type(origin_cls.__name__,
                        origin_cls.__bases__, dict(origin_cls.__dict__))
    _fcn = getattr(origin_cls, method_name)

    def child_func(*args, **kwargs):
        """Do child_func"""
        if ((args == ([], '*.mo')
             or args == (['*.mo'], '**')) and method_name == "append")\
                or (args == ('**/*.mo', '/') and method_name == "split"):
            return _fcn(*args, **kwargs)
        result = copyNewClass.__dict__[method_name](*args, **kwargs)

        result = wrap_data(
            result, origin_cls.__name__, _fcn,
            signature=signature, source=source, come_data=args)

        return result
    return child_func


def wrap_data(result, origin_cls, _fcn, signature=None,
              source=False, come_data=None):
    """Do wrap_data"""
    return result
