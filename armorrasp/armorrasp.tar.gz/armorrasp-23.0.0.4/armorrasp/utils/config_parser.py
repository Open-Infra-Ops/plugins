"""Do config_parser"""


class RaspConfig:
    """Do RaspConfig"""

    # 日志开关
    log_disable = False

    # 日志级别
    log_level = 'INFO'

    # 检测特性开关
    cmdi_switch = True
    sqli_switch = True
    xss_switch = True
    deserialization_switch = True
    webshell_upload_switch = True
    dir_traversal_switch = True
    zeroday_switch = True

    # 阻断开关
    cmdi_block = False
    sqli_block = False
    xss_block = False
    deserialization_block = False
    webshell_upload_block = False
    dir_traversal_block = False
    zeroday_block = False

    # 检测特性黑名单
    cmdi_black = ('!', ';', '&', '<', '>', '|', '~', '`', 'whoami')
    webshell_upload_black = ('.py', '.sh', '.cgi', '.perl', '.pl')
    dir_traversal_black = ('../', '/etc', '/proc', '/sys', '/var/log')
    zeroday_black = ("eval", "exec", "reload")
