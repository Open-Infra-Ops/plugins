"""Do base_frameworks"""
import json
import re
import sys
import uuid
from collections import defaultdict

from armorrasp.config import logger_config
from armorrasp.utils.util import HAS_TYPING, secured_unicode, \
    form_params_resolve, acquire_all_iterable, \
    judge_unicode, cached_property, is_string

if sys.version_info[0] >= 3:
    from http.cookies import SimpleCookie
    from urllib.parse import unquote_to_bytes
else:
    from urllib import unquote as unquote_to_bytes

    from Cookie import SimpleCookie


if HAS_TYPING:
    from typing import List

logger = logger_config("base_frameworks")


def _normalize_str(string):
    """Do _normalize_str"""
    return re.sub("\\s+", "", string).lower()


def _get_param(param, check_value):
    """Do _get_param"""
    if param and is_string(param) and len(param) >= 8:
        normalized_param_value = _normalize_str(param)
        if normalized_param_value in check_value:
            return param

    return None


class BasisRequest(object):
    """Do BasisRequest"""
    def __init__(self):
        pass

    @property
    def remote_addr(self):
        raise NotImplementedError

    @property
    def hostname(self):
        raise NotImplementedError

    @property
    def request_method(self):
        raise NotImplementedError

    @property
    def header_referer(self):
        raise NotImplementedError

    @property
    def user_agent(self):
        raise NotImplementedError

    @property
    def request_path(self):
        raise NotImplementedError

    @property
    def scheme(self):
        raise NotImplementedError

    @property
    def raw_headers(self):
        raise NotImplementedError

    @property
    def query_string(self):
        raise NotImplementedError

    @cached_property
    def query_params_to_dict(self):
        raw_query_string = self.query_string
        try:
            return form_params_resolve(raw_query_string)
        except Exception:
            logger.debug(
                "can't parse URL query %s", raw_query_string, exc_info=True
            )
            return {}

    @property
    def view_params(self):
        raise NotImplementedError

    @property
    def body(self):
        raise NotImplementedError

    @property
    def json_body_to_dict(self):
        try:
            body_data = self.body
            content_type = secured_unicode(self.content_type)
            if content_type.startswith("application/json") \
                    and content_type is not None and body_data:
                try:
                    return json.loads(body_data)
                except TypeError:
                    return json.loads(secured_unicode(body_data))
        except Exception:
            logger.debug("can't parse input json", exc_info=True)
        return {}

    @property
    def request_uri(self):
        uri = [self.request_path]
        raw_query_string = self.query_string
        if raw_query_string:
            uri.append("?")
            query_string = raw_query_string.replace('+', ' ')
            if sys.version_info[0] >= 3 and hasattr(query_string, "encode"):
                query_string = query_string.encode(errors="surrogatepass")
            # 对非 ASCII 字符进行处理
            uri.append(secured_unicode(unquote_to_bytes(query_string)))
        return "".join(uri)

    @property
    def form_body_to_dict(self):
        try:
            body_data = self.body
            content_type = secured_unicode(self.content_type)

            if content_type == "application/x-www-form-urlencoded" \
                    and content_type is not None and body_data:
                return form_params_resolve(body_data)
        except Exception:
            logger.debug("can't parse input json", exc_info=True)
        return {}

    @property
    def body_params(self):
        return self.form_body_to_dict or self.json_body_to_dict

    @cached_property
    def request_uuid(self):
        return uuid.uuid4()

    @property
    def request_id(self):
        return self.request_uuid.hex

    @property
    def raw_cookies(self):
        raise NotImplementedError

    @property
    def cookies_params(self):
        raw_cookies = self.raw_cookies
        if raw_cookies:
            try:
                raw_cookie = SimpleCookie()
                # py2 和 py3 的处理逻辑不同
                if sys.version_info[0] == 2 and judge_unicode(raw_cookies):
                    raw_cookies = raw_cookies.encode(errors="surrogatepass")
                raw_cookie.load(raw_cookies)
                return {key: raw_cookie[key].coded_value
                        for key in raw_cookie.keys()}
            except Exception:
                logger.debug("can't parse cookies", exc_info=True)
        return {}

    @property
    def request_params(self):
        return {
            "form": str(self.form_body_to_dict),
            "query": self.query_params_to_dict,
            "other": str(self.view_params),
            "json": str(self.json_body_to_dict),
        }

    @property
    def request_params_list(self):
        return [
            self.form_body_to_dict,
            self.query_params_to_dict,
            self.view_params,
            self.json_body_to_dict,
        ]

    @property
    def get_all_request_params(self):
        param_keys, param_values = \
            acquire_all_iterable(self.request_params_list)
        return param_keys, param_values

    def params_contains(self, param):
        return param in self.get_all_request_params[1]

    def check_user_input(self, need_check_value):
        if is_string(need_check_value):
            normalized_value = _normalize_str(need_check_value)

            keys = self.get_all_request_params[0]
            values = self.get_all_request_params[1]

            for index in range(0, len(values)):
                param = _get_param(values[index], normalized_value)
                if param:
                    return keys[index], param

        return None

    @property
    def content_type(self):
        return self.get_raw_header("CONTENT_TYPE")

    @property
    def content_length(self):
        content_length = self.get_raw_header("CONTENT_LENGTH")
        if content_length is not None:
            try:
                return int(content_length)
            except ValueError:
                pass
        return None

    @cached_property
    def request_headers_dict(self):
        request_headers_dict = defaultdict(lambda: None)
        for key, value in self.raw_headers.items():
            key = secured_unicode(key)
            if not key.startswith("HTTP_"):
                if key == "CONTENT_LENGTH" and value:
                    pass
                elif key != "CONTENT_TYPE":
                    continue
            request_headers_dict[key] = secured_unicode(value)
        return request_headers_dict

    def get_raw_header(self, name, default=None):
        return self.raw_headers.get(name, default)

    @property
    def client_ip(self):
        ip = self.raw_client_ip
        if ip is not None:
            return secured_unicode(ip)

    @cached_property
    def raw_client_ip(self):
        return self.get_raw_header("HTTP_CLIENT_IP")

    @property
    def headers_no_cookies(self):
        result = {}
        for key, value in self.request_headers_dict.items():
            header_name = key.lower().replace("_", "-")
            if header_name.startswith("http-"):
                header_name = header_name[5:]
            if header_name == "cookie":
                continue
            result[header_name] = value
        return result

    @property
    def attack_request_info(self):
        return {
            "request_id": self.request_id,
            "request_method": self.request_method,
            "client_ip": self.client_ip,
            "parameter": self.request_params,
            "attack_source": self.remote_addr,
            "url": self.request_uri,
            "target": self.hostname,
            "header": self.headers_no_cookies,
            "path": self.request_path,
        }

    @property
    def route(self):
        return None
