"""Do cmdi init work"""
