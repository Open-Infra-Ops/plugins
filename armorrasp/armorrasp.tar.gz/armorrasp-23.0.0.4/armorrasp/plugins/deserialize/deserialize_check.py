"""Do deserialize_check"""
from armorrasp.config import CONFIG
from armorrasp.info.record_attack import record_attack
from armorrasp.utils import pyrasp_exception
from armorrasp.config import logger_config
from armorrasp.utils.wrappor import exception_catch

logger = logger_config("deserialize_check")


NEW_LINE = "\n"
ESCAPED_NEW_LINE = "\\n"
PYTHON_TAG = "!!python"


def pickle_check(check_param):
    """Do pickle_check"""
    split_char = (
        ESCAPED_NEW_LINE if ESCAPED_NEW_LINE in check_param else NEW_LINE
    )
    stack_commands = check_param.split(split_char)
    count = 0

    for command in stack_commands:
        contains_command = \
            any(m in command for m in CONFIG["DESERIALIZATION_BLACK"])

        if contains_command:
            count += 1

            # pushing module only the stack
            if command.startswith("c"):
                count += 1

    if count >= 2:
        return True

    return False


class UntrustedDeserialize:
    """Do UntrustedDeserialize"""

    @classmethod
    @exception_catch("Failed to check deserialize", return_value="")
    def deserialize_detect(cls, queue, type_string, check_param):
        is_attack = False
        mess = ""

        sensitive_str = CONFIG["DESERIALIZATION_BLACK"]

        for sen_str in sensitive_str:
            if sen_str in check_param:
                is_attack = True
                mess = \
                    'Deserialization - Detected dangerous method call {0} ' \
                    'in deserialization query'.format(sen_str)
                break

        # 如果开启了阻断且包含特殊命令连接符则阻断攻击，否则只报警
        if not is_attack:
            return None
        if CONFIG["DESERIALIZATION_BLOCK"]:
            record_attack(queue, "deserialization",
                          "block", mess,
                          params=check_param)
            raise pyrasp_exception. \
                RaspSecurityException('Untrusted Deserialization')
        record_attack(queue, "deserialization",
                      "log", mess,
                      params=check_param)
        return
