"""Do util"""
import hashlib
import sys
import datetime
from collections import defaultdict, deque
from itertools import islice

PY2 = sys.version_info[0] == 2
PY3 = sys.version_info[0] == 3

if PY2:
    from urllib import unquote as unquote_to_bytes
else:
    from urllib.parse import unquote_to_bytes

if sys.version_info < (3, 5):
    from collections import Iterable, Mapping

    HAS_TYPING = False

else:
    from typing import (
        Any,
        Callable,
        Dict,
        Iterable,
        List,
        Mapping,
        Optional,
        Set,
        Tuple,
    )

    HAS_TYPING = True


HAS_ASYNCIO = sys.version_info >= (3, 4)

ZERO_TD = datetime.timedelta(0)

if PY2:
    ALL_STRING_CLASS = basestring  # noqa
    STRING_CLASS = str
    UNICODE_CLASS = unicode  # noqa
    INTEGER_CLASS = (int, long)  # noqa
    BINARY_CLASS = str
    TEXT_CLASS = unicode  # noqa


    def iterkeys(data, **kwargs):
        """Do if iterkeys"""
        return data.iterkeys(**kwargs)


    def itervalues(data, **kwargs):
        """Do if itervalues"""
        return data.itervalues(**kwargs)


    class OffsetConstantTZ(datetime.tzinfo):
        """Do OffsetConstantTZ"""

        def __init__(self, offset, name):
            self.__name = name
            self.__offset = datetime.timedelta(minutes=offset)

        def tzname(self, dt):
            return self.__name

        def utcoffset(self, dt):
            return self.__offset

        def dst(self, dt):
            return ZERO_TD


    UTC = OffsetConstantTZ(0, "UTC")

else:

    STRING_CLASS = str
    ALL_STRING_CLASS = str
    UNICODE_CLASS = str
    INTEGER_CLASS = int
    BINARY_CLASS = bytes
    TEXT_CLASS = str


    def viewkeys(data, **kwargs):
        """Do else viewkeys"""
        return data.keys(**kwargs)


    iterkeys = viewkeys


    def itervalues(data, **kwargs):
        """Do else itervalues"""
        return data.values(**kwargs)


    OffsetConstantTZ = datetime.timezone

    UTC = datetime.timezone.utc


def judge_unicode(value):
    """Do judge_unicode"""
    return isinstance(value, UNICODE_CLASS)


def secured_unicode(su_value):
    """Do secured_unicode"""
    if su_value is None:
        return su_value

    if isinstance(su_value, bytes):
        return su_value.decode("utf-8", errors="replace")

    if not judge_unicode(su_value):
        su_value = STRING_CLASS(su_value)

        if isinstance(su_value, bytes):
            return su_value.decode("utf-8", errors="replace")

    return su_value


def ip_address(ipaddress):
    """Do ip_address"""
    return ipaddress


def is_string(value):
    """Do is_string"""
    return isinstance(value, ALL_STRING_CLASS)


def now():
    """Do now"""
    return datetime.datetime.now(UTC)


def get_string_md5(string):
    """Do get_string_md5"""
    value_m = hashlib.md5(string.encode("utf-8"))
    return value_m.hexdigest()


def acquire_all_iterable(iterable, value_max=30):
    """Do acquire_all_iterable"""
    iteration_value = 0
    iterator_keys = []
    iterator_values = []
    remaining_iterables = deque([iterable], maxlen=value_max)
    seen_iterables = set()

    while remaining_iterables:

        iteration_value += 1
        if iteration_value >= value_max:
            break

        iterable = remaining_iterables.popleft()
        id_iterable = id(iterable)
        if id_iterable in seen_iterables:
            continue
        seen_iterables.add(id_iterable)

        if isinstance(iterable, Mapping):
            iterator_keys.extend(islice(iterkeys(iterable), value_max))
            remaining_iterables.extend(islice(itervalues(iterable),
                                              value_max))
        elif isinstance(iterable, (list, tuple)):
            remaining_iterables.extend(islice(iter(iterable), value_max))
        else:
            iterator_values.append(iterable)

    return iterator_keys, iterator_values


missing = object()


class cached_property(property):
    """Do cached_property"""

    def __init__(self, func, name=None, doc=None):
        super(cached_property, self).__init__()
        self.__name__ = name or func.__name__
        self.__module__ = func.__module__
        self.__doc__ = doc or func.__doc__
        self.func = func

    def __set__(self, obj, value):
        obj.__dict__[self.__name__] = value

    def __get__(self, obj, get_type=None):
        if obj is None:
            return self
        value = obj.__dict__.get(self.__name__, missing)
        if value is missing:
            value = self.func(obj)
            if value is missing:
                return None
            obj.__dict__[self.__name__] = value
        return value


def ensure_input_string(e_i_s, encoding='utf-8', errors='ignore'):
    """Do ensure_input_string"""
    BYTEARRAY_CLASS = bytearray
    if type(e_i_s) is str:
        return e_i_s
    if PY2 and isinstance(e_i_s, TEXT_CLASS):
        return e_i_s.encode(encoding, errors)
    elif PY3 and isinstance(e_i_s, BINARY_CLASS):
        return e_i_s.decode(encoding, errors)
    elif isinstance(e_i_s, BYTEARRAY_CLASS):
        return e_i_s.decode(encoding, errors)
    elif not isinstance(e_i_s, (TEXT_CLASS, BINARY_CLASS)):
        raise TypeError("not expecting type '%s'" % type(e_i_s))
    return e_i_s


def form_params_resolve(qs_value):
    """Do form_params_resolve"""
    dict_params = defaultdict(list)
    qs_value = secured_unicode(qs_value).replace("+", " ")

    for entry in qs_value.split("&"):
        qs_key, qs_equal, qs_value = entry.partition("=")
        if qs_equal:
            dict_params[secured_unicode(unquote_to_bytes(qs_key))] \
                .append(secured_unicode(unquote_to_bytes(qs_value)))
    return dict(dict_params)
