"""Do alarm_queue"""
import itertools
import sys

if sys.version_info[0] < 3:
    from Queue import Empty, Full, Queue
else:
    from queue import Empty, Full, Queue


class AlarmQueue(object):
    """Do AlarmQueue"""
    def __init__(self):
        self.maxsize = 4096
        self.queue = Queue(self.maxsize)
        self._count_ingress = itertools.count()
        self._count_dropped = itertools.count()
        self._count_egress = itertools.count()
        self._last_count_ingress = 0
        self._last_count_dropped = 0
        self._last_count_egress = 0

    def get(self, timeout, block=True):
        """ Wait for up to timeout for an item to return and block while
        waiting
        """
        ret = self.queue.get(timeout=timeout, block=block)
        next(self._count_egress)
        return ret

    def get_nowait(self):
        """ Get without waiting, raise queue.Empty if nothing is present
        """
        ret = self.queue.get_nowait()
        next(self._count_egress)
        return ret

    def put(self, item):
        """ Tries to put an item to the queue, if the queue is full, pop an
        item and try again
        """
        while True:
            try:
                ret = self.queue.put_nowait(item)
                next(self._count_ingress)
                return ret
            except Full:
                try:
                    self.queue.get_nowait()
                    self.queue.task_done()
                    next(self._count_dropped)
                except Empty:
                    pass

    def half_full(self):
        """ Return True if the current queue size if at least half the maxsize
        """
        return self.queue.qsize() > (self.maxsize / 2.)

    def task_done(self):
        """ Inform the queue that an event was processed.
        """
        self.queue.task_done()

    def join(self):
        """ Block until all events are consumed
        """
        self.queue.join()

    def empty(self):
        """ Block until all events are consumed
        """
        self.queue.empty()
