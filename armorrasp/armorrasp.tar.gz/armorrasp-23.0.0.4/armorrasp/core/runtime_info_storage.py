"""Do runtime_info_storage"""
import threading

import pkg_resources

from armorrasp.utils.util import HAS_ASYNCIO


class RuntimeInfoMemory(object):
    """Do RuntimeInfoMemory"""
    def __init__(self, store=None):
        if store is None:
            store = _ThreadLocalStore()
        self.store = store

    def memory_request(self, request, **kwargs):
        self.store.set("latest_request", request)

    def get_latest_request(self):
        return self.store.get("latest_request")

    def memory_request_default(self, request, **kwargs):
        latest_request = self.get_latest_request()
        if latest_request is None:
            self.memory_request(request, **kwargs)

    def memory_delete(self):
        self.store.delete("latest_request")

    def clear_request(self, queue=None, observation_queue=None):
        """Clear the stored request."""
        self.store.delete("whitelist_match")
        self.store.delete("latest_request_input_preview")
        self.store.delete("latest_request_store")
        latest_request = self.store.delete("latest_request")
        latest_response = self.store.delete("latest_response")
        latest_recorder = self.store.get("latest_recorder")
        if latest_recorder is not None:
            latest_recorder.end_request()
            if latest_request is not None and queue is not None \
                    and observation_queue is not None:
                latest_recorder.flush(
                    latest_request, latest_response,
                    self.payload_creator, queue, observation_queue
                )
            else:
                latest_recorder.clear()

    def memory_request_input_preview(self, preview, end_of_input):
        self.store.set("latest_request_input_preview",
                       (preview, end_of_input))

    def get_request_input_preview(self):
        return self.store.get("latest_request_input_preview", (None, None))


class _ThreadLocalStore(object):
    """Do ThreadLocalStore"""

    def __init__(self):
        self.local = threading.local()

    def get(self, key, default=None):
        return getattr(self.local, key, default)

    def set(self, key, value):
        setattr(self.local, key, value)

    def setdefault(self, key, value):
        return self.local.__dict__.setdefault(key, value)

    def delete(self, key):
        return self.local.__dict__.pop(key, None)


_THREADED_FRAMEWORKS = ("Django", "Flask")


def _get_memory():
    """Return a store object suited for the current framework."""
    if HAS_ASYNCIO:
        pkg_names = set(
            pkg_info.project_name for pkg_info in pkg_resources.working_set
        )
        for framework in _THREADED_FRAMEWORKS:
            if framework in pkg_names:
                return _ThreadLocalStore()

    return _ThreadLocalStore()


def get_runtime_memory():
    """Return a runtime storage instance suited for the current framework."""
    return RuntimeInfoMemory(_get_memory())


runtime = get_runtime_memory()
