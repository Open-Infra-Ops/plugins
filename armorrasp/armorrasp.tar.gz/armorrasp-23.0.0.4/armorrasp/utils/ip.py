"""Do ip"""
from armorrasp.utils.util import ip_address


def deal_user_ip(ip):
    """Do deal_user_ip"""
    ip = ip.strip()
    if not ip:
        return
    try:
        if '.' in ip and ':' in ip:
            ip = ip.split(':')[0]

        ip = ip_address(ip)
        return ip
    except ValueError:
        return


def found_far_global_ip(operating_addr, individual_ip):
    """Do found_far_global_ip"""
    # If no global IP was found so far.
    try:
        real_ip = ip_address(operating_addr)
    except ValueError:
        return individual_ip  # May be None.
    if individual_ip is None or real_ip.is_global:
        return real_ip
    else:
        return individual_ip


def acquire_user_actual_ip(operating_addr, *ips):
    """ Try to compute the real user ip from various headers
    """
    individual_ip = None
    for list_ips in ips:
        for ip in list_ips.split(","):
            ip = deal_user_ip(ip)
            if not ip:
                continue
            if ip.is_global:
                return ip
            elif individual_ip is None and not ip.is_loopback \
                    and ip.is_private:
                individual_ip = ip
    found_far_global_ip(operating_addr, individual_ip)
