"""Do wsgi_base"""
import sys

from armorrasp.core.frameworks.base_frameworks import BasisRequest

from armorrasp.utils.util import secured_unicode

if sys.version_info[0] >= 3:
    from urllib.parse import quote
else:
    from urllib import quote


class BasisWSGIRequest(BasisRequest):
    """ Base class for WSGI based framework requests.
    """

    @property
    def body(self):
        from armorrasp.core.runtime_info_storage import runtime

        body, _ = runtime.get_request_input_preview()
        return body

    @property
    def query_string(self):
        return secured_unicode(self.get_raw_header("QUERY_STRING"))

    @property
    def view_params(self):
        return {}

    @property
    def raw_cookies(self):
        return secured_unicode(self.get_raw_header("HTTP_COOKIES"))

    @property
    def remote_addr(self):
        """Remote IP address."""
        return secured_unicode(self.get_raw_header("REMOTE_ADDR"))

    @property
    def hostname(self):
        return \
            secured_unicode(self.
                            get_raw_header("HTTP_HOST",
                                           self.
                                           get_raw_header("SERVER_NAME")))

    @property
    def request_path(self):
        return quote(self.get_raw_header("SCRIPT_NAME", "")) + quote(
            self.get_raw_header("PATH_INFO", "")
        )

    @property
    def request_method(self):
        return secured_unicode(self.get_raw_header("REQUEST_METHOD"))

    @property
    def user_agent(self):
        return secured_unicode(self.get_raw_header("HTTP_USER_AGENT"))

    @property
    def header_referer(self):
        return secured_unicode(self.get_raw_header("HTTP_REFERER"))

    @property
    def scheme(self):
        return secured_unicode(self.get_raw_header("wsgi.url_scheme"))


class WSGIRequest(BasisWSGIRequest):
    """ Helper around raw wsgi environ
    """

    def __init__(self, environ):
        super(WSGIRequest, self).__init__()
        self.environ = environ

    @property
    def raw_headers(self):
        return self.environ
