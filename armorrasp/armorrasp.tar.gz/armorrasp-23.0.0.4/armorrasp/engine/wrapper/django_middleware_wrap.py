"""Do django_middleware_wrap"""
from armorrasp.core.frameworks.django_framework import BasisDjangoRequest
from armorrasp.core.runtime_info_storage import runtime
from armorrasp.config import logger_config

logger = logger_config("django_middleware_wrap")


class DjangoMiddlewareWrap(object):
    """Do DjangoMiddlewareWrap"""

    @staticmethod
    def observe_process(request,
                        callback, callback_args, callback_kwargs):
        runtime.memory_request(BasisDjangoRequest(request))
        return None

    @staticmethod
    def respond_process(request, response):
        # Record request if we don't have one yet
        runtime.memory_request_default(BasisDjangoRequest(request))

        # Execute pre_callbacks if the response is a 404 because the callback
        # observe_process was not called by Django
        if response.status_code == 404:
            runtime.memory_request(BasisDjangoRequest(request))
        return response

    @staticmethod
    def abnormal_process(request, exception):
        # Record request if we don't have one yet
        runtime.memory_request_default(BasisDjangoRequest(request))
        return None
