#! /bin/sh
# chkconfig: 2345 55 25
# Description: Service Monitor
# Copyright (C) 2019 Huawei Technologies Co., Ltd.
### BEGIN INIT INFO
# Provides:servicemonitor
# Required-Start:
# Required-Stop:
# Should-Stop:
# Default-Start: 2 3 4 5
# Default-Stop: 0 1 6
# Description: Start the ServiceMonitor service
### END INIT INFO

INSTALL_DIR=/usr/local/spes/Composites/Sacc
BIN_PATH=$INSTALL_DIR/servicemonitor

EXIST=1
NOTEXIST=0
NOPID=0

procexists ()
{
  pidno=`ps -ef|grep -v "ps -ef"|grep -v grep|grep "$1"|awk '{print $2}'`
  if [ -z "$pidno" ]
  then
    return $NOTEXIST
  else
    return $EXIST
  fi
}

getpid ()
{
  pidno=`ps -ef|grep -v "ps -ef"|grep -v grep|grep "$1"|awk '{print $2}'`
  if [ -z "$pidno" ]
  then
    echo "$NOPID"
  else
    echo "$pidno"
  fi
}

startsrvmonitor()
{
  procexists $BIN_PATH
  if [ "$?" -eq "$NOTEXIST" ]
  then
    echo \ "Starting Service Monitor daemon "

    $BIN_PATH
	  sleep 1
    procexists "$BIN_PATH"
    if [ "$?" -eq "$NOTEXIST" ]
    then
      echo \ "Starting Service Monitor failed."
    fi
  else
    pid=`getpid $BIN_PATH`
    echo \ "Service Monitor($pid) is already running!"
  fi
}

stopproc()
{
  procexists $1
  if [ "$?" -ne "$NOTEXIST" ]; then
    pid=`getpid $1`
    if [ $pid -ne "0" ]; then
      kill -9 $pid
    fi
  fi
}

stopsrvmonitor()
{
  #stop srvmonitor
	procexists $BIN_PATH
  if [ "$?" -eq "$NOTEXIST" ]
  then
    echo \ "Service Monitor is not running! "
  else
    echo \ "Shutting down Service Monitor daemon..."
    pid=`getpid $BIN_PATH`
    kill -9 $pid
  fi

  for i in $(seq 1 5)
  do
    sleep 1
    procexists "$BIN_PATH"
    if [ "$?" -eq "$NOTEXIST" ]
    then
      break
    fi
  done
}

statussrvmonitor()
{
  procexists "$BIN_PATH"
  if [ "$?" -eq "$NOTEXIST" ]
  then
    echo \ "Service Monitor is not running!"
  else
    pid=`getpid $BIN_PATH`
    echo \ "Service Monitor($pid) is already running!"
  fi
}

version()
{
  cat $INSTALL_DIR/ClientVersion 
}

case "$1" in
  start)
    startsrvmonitor
    ;;
  stop)
    stopsrvmonitor
    ;;
  restart)
    stopsrvmonitor
    startsrvmonitor
    ;;
  status)
    statussrvmonitor
    ;;
  version)
    version
    ;;
  *)
    echo "Usage: $0 {start|stop|restart|status|version}"
    exit 1
    ;;
esac

