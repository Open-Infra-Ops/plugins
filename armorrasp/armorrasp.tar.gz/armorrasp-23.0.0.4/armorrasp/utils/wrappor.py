"""Do wrappor"""
from armorrasp.config import logger_config
from armorrasp.utils.pyrasp_exception import RaspSecurityException

logger = logger_config("exception_catch")


def _log_message(message, exception, args, kwargs, log_level="debug"):
    """Do _log_message"""
    try:
        getattr(logger, log_level)(message + ": " + str(exception))
    except Exception:
        pass


def exception_catch(message, log_level="exception", return_value=None):
    """Do exception_catch"""
    def wrapped(ori_fun):
        """Do wrapped"""
        def run_safely(*args, **kwargs):
            """Do run_safely"""
            try:
                return ori_fun(*args, **kwargs)
            except RaspSecurityException:
                raise
            except Exception as exception:
                _log_message(message, exception, args, kwargs, log_level)
            return return_value

        return run_safely

    return wrapped
