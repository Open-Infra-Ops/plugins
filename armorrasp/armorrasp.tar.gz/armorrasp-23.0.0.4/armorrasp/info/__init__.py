"""Do info init work"""
