"""Do stack_utils"""
import traceback

from armorrasp.app_context import XARMOR_BASE_HOME, SYS_PATH
from armorrasp.utils.wrappor import exception_catch


APPLIES_MARKER = "cs__"
PATCH_MARKER = "__cs"

DJANGO_EXCEPTION_PATH = "core/handlers/exception.py"
DJANGO_DEPRECATION_PATH = "utils/deprecation.py"


@exception_catch("Failed to get stacktrace", return_value=[])
def get_raw_stack():
    """Do get_raw_stack"""

    return traceback.extract_stack(limit=30)


@exception_catch("Failed to filter stacktrace", return_value=[])
def filter_stack(stack_frames, depth=20):
    """Do filter_stack"""
    stack_frames.reverse()

    frames = [frame for frame in stack_frames if filter_frame(frame)]

    return to_element_list(frames[:depth])


@exception_catch("Failed to filter stacktrace string", return_value=[])
def filter_stack_string(stack_frames, depth=20):
    """Do filter_stack_string"""
    stack_frames.reverse()

    frames = [frame for frame in stack_frames if filter_frame(frame)]

    return to_element_string_list(frames[:depth])


def filter_frame(frame):
    """Do filter_frame"""

    ignore_string = "armorrasp"

    if isinstance(frame, tuple):
        return (
            ignore_string not in frame[0]
            and not frame[2].startswith(APPLIES_MARKER)
            and not frame[2].startswith(PATCH_MARKER)
            and not frame[0].endswith(DJANGO_EXCEPTION_PATH)
            and not frame[0].endswith(DJANGO_DEPRECATION_PATH)
        )

    return (
        ignore_string not in frame.filename
        and not frame.name.startswith(APPLIES_MARKER)
        and not frame.name.startswith(PATCH_MARKER)
        and not frame.filename.endswith(DJANGO_EXCEPTION_PATH)
        and not frame.filename.endswith(DJANGO_DEPRECATION_PATH)
    )


def to_element_list(frames):
    """Do to_element_list"""
    return [y for y in [to_element(x) for x in frames] if y is not None]


def to_element_string_list(frames):
    """Do to_element_string_list"""
    return [to_element_string(x) for x in frames]


@exception_catch("Failed to convert summary to tuple")
def to_element(summary):
    """Do to_element"""
    if not summary:
        return None

    if isinstance(summary, tuple):
        path = summary[0]
        method = summary[2]
        line_number = summary[1]
    else:
        path = summary.filename
        method = summary.name
        line_number = summary.lineno

    file_name = filename_formatter(path)

    return file_name, path, method, line_number


@exception_catch("Failed to convert summary to string")
def to_element_string(summary):
    """Do to_element_string"""
    if not summary:
        return None

    if isinstance(summary, tuple):
        method = summary[2]
        line_number = summary[1]
        path = summary[0]
    else:
        path = summary.filename
        method = summary.name
        line_number = summary.lineno

    return "{}-{}-{}".format(path, method, line_number)


def filename_formatter(file_name):
    """Do filename_formatter"""
    if file_name.startswith("<frozen"):
        return file_name

    formatted = None

    if file_name.startswith(XARMOR_BASE_HOME):
        formatted = file_name.replace(XARMOR_BASE_HOME, "")
    else:
        for sys_path in SYS_PATH:
            if file_name.startswith(sys_path):
                formatted = file_name.replace(sys_path, "")
                break

    formatted = formatted or file_name

    return formatted.replace("/", ".").lstrip(".")


def get_filtered_stack(depth=20):
    """Do get_filtered_stack"""
    stack_frames = get_raw_stack()
    return filter_stack(stack_frames, depth=depth)


def get_filtered_stack_string_list(depth=20):
    """Do get_filtered_stack_string_list"""
    stack_frames = get_raw_stack()
    return filter_stack_string(stack_frames, depth=depth)
