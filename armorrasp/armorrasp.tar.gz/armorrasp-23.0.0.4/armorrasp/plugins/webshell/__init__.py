"""Do webshell init work"""
