"""Do flask_framework"""
import sys
from copy import deepcopy

from armorrasp.core.frameworks.wsgi_base import BasisWSGIRequest
from armorrasp.config import logger_config
from armorrasp.utils.util import itervalues, secured_unicode, cached_property

if sys.version_info[0] >= 3:
    import urllib.parse as urlparse
else:
    import urlparse

logger = logger_config("flask_framework")


class BasisFlaskRequest(BasisWSGIRequest):
    """Do BasisFlaskRequest"""

    def __init__(self, request):
        super(BasisFlaskRequest, self).__init__()
        self.request = request

    def request_preloaded(self):
        try:
            # Fill request._cached_data
            self.request.get_data()
            # Reload request.stream to use request._cached_data
            request_stream = self.request._get_stream_for_parsing()
            self.request.__dict__["stream"] = request_stream
            if self.judege_flask_framework_api:
                # Flask-API uses request._stream
                self.request._stream = request_stream
        except Exception:
            logger.debug("can't get request.data from framework",
                         exc_info=True)
            return False
        else:
            return True

    def data_preloaded(self):

        if hasattr(self.request, "_cached_data"):
            return True
        content_length = self.content_length
        # Safety, do not preload data if the body is too heavy
        # XXX: this should be a parameter.
        if content_length is None or content_length > 4096:  # 4KB
            return False
        self.request_preloaded()

    @cached_property
    def query_params_to_dict(self):
        try:
            # Convert flask QueryDict to a normal dict with values as list
            # XXX: multiple values with the same key
            return dict(self.request.args.lists())
        except Exception:
            logger.debug("can't get request.args from framework",
                         exc_info=True)
            return super(BasisFlaskRequest, self).query_params_to_dict

    @property
    def body(self):

        try:
            if self.data_preloaded():
                return self.request.get_data()
        except Exception:
            logger.debug("can't get request.data from framework",
                         exc_info=True)
        return super(BasisFlaskRequest, self).body

    def _load_form(self):
        req_dict = self.request.__dict__
        req_stream = req_dict["stream"]
        # Parsing the form data consumes request.stream
        self.request._load_form_data()
        # Reload request.stream
        req_dict["stream"] = req_stream
        req_redict = self.__dict__
        # XXX: multiple values with the same key
        req_redict["form_body_to_dict"] = dict(req_dict["form"].lists())
        req_redict["files_field_names"] = list(req_dict["files"].keys())
        filenames = set()
        combined_size = 0
        for file_memory in itervalues(req_dict["files"]):
            file_name = file_memory.filename
            if file_name:
                filenames.add(file_name)
            context_length = file_memory.content_length
            if context_length is not None:
                combined_size += context_length
        req_redict["filenames"] = list(filenames)
        req_redict["combined_file_size"] = combined_size

    @cached_property
    def form_body_to_dict(self):
        try:
            if self.data_preloaded():
                self._load_form()
                return self.form_body_to_dict
        except Exception:
            logger.debug("can't get request.form from framework",
                         exc_info=True)
        return super(BasisFlaskRequest, self).form_body_to_dict

    @cached_property
    def files_field_names(self):
        try:
            if self.data_preloaded():
                self._load_form()
                return self.files_field_names
        except Exception:
            logger.debug("can't get request.files from framework",
                         exc_info=True)
        return []

    @cached_property
    def filenames(self):
        try:
            if self.data_preloaded():
                self._load_form()
                return self.filenames
        except Exception:
            logger.debug("can't get request.files from framework",
                         exc_info=True)
        return []

    @cached_property
    def combined_file_size(self):
        try:
            if self.data_preloaded():
                self._load_form()
                return self.combined_file_size
        except Exception:
            logger.debug("can't get request.files from framework",
                         exc_info=True)
        return None

    @cached_property
    def cookies_params(self):
        try:
            return dict(self.request.cookies)
        except Exception:
            logger.debug("can't get request.cookies from framework",
                         exc_info=True)
        return super(BasisFlaskRequest, self).cookies_params

    @cached_property
    def _json(self):
        get_json_params = self.request.get_json(silent=True)
        return deepcopy(get_json_params)

    @property
    def json_body_to_dict(self):
        try:
            if self.data_preloaded():
                return self._json
        except Exception:
            logger.debug("can't get request.json from the framework",
                         exc_info=True)
        return super(BasisFlaskRequest, self).json_body_to_dict

    @property
    def remote_addr(self):
        return secured_unicode(self.get_raw_header("REMOTE_ADDR"))

    @property
    def hostname(self):
        try:
            url_root = self.request.url_root
            return urlparse.urlparse(url_root).netloc
        except Exception:
            logger.debug("can't get request.get_host from the framework",
                         exc_info=True)
            return None

    @property
    def request_method(self):
        return secured_unicode(self.request.method)

    @property
    def header_referer(self):
        return self.request.referrer

    @property
    def route(self):
        url_rule = getattr(self.request, "url_rule", None)

        return getattr(url_rule, "rule", None)

    @property
    def request_path(self):
        return self.request.path

    @property
    def scheme(self):
        return secured_unicode(self.request.scheme)

    @property
    def raw_headers(self):
        return self.request.environ

    @property
    def view_params(self):
        return self.request.view_args

    @property
    def judege_flask_framework_api(self):
        return hasattr(self.request, "empty_data_class") \
               and "flask_api" in sys.modules
