#!/bin/sh


#check the OS
#arch = `uname`)
if [ -f "/etc/mandriva-release" ]; then
	OS="Mandriva"
elif [ -f "/etc/slackware-version" ]; then
	OS="Slackware"
elif [ -f "/etc/euleros-release" ]; then
	OS="Euler"
elif [ -f "/etc/centos-release" ]; then
	OS="CentOS"
elif [ `uname` = "Darwin" ]; then
  OS="Darwin"
elif [ -f "/etc/SuSE-release" ]; then
	OS="SuSE"
elif [ -f "/etc/redhat-release" ]; then
	OS="Redhat"
elif [ -f "/etc/openEuler-release" ]; then
	OS="openEuler"
else
	UBUNTU_LINE=`cat /etc/lsb-release | grep -i ubuntu | wc -l`
	if [ "$UBUNTU_LINE" -gt 0 ]; then
		OS="Ubuntu"
	fi
	SUSE_LINE=`cat /etc/os-release | grep -i suse | wc -l`
	if [ "$SUSE_LINE" -gt 0 ]; then
		OS="SuSE"
	fi
	CENTOS_LINE=`cat /etc/os-release | grep -i centos | wc -l`
	if [ "$CENTOS_LINE" -gt 0 ]; then
		OS="CentOS"
	fi
	REDHAT_LINE=`cat /etc/os-release | grep -i redhat | wc -l`
	if [ "$REDHAT_LINE" -gt 0 ]; then
		OS="Redhat"
	fi
	DEEPIN_LINE=`cat /etc/os-release | grep -i deepin | wc -l`
	if [ "$DEEPIN_LINE" -gt 0 ]; then
		OS="Deepin"
	fi
	UOS_LINE=`cat /etc/os-release | grep -i uos | wc -l`
	if [ "$UOS_LINE" -gt 0 ]; then
		OS="UOS"
	fi
fi 
echo "OS is $OS"
