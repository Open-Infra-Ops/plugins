"""Do flask_middleware"""
from armorrasp.core.frameworks.flask_framework import BasisFlaskRequest
from armorrasp.core.runtime_info_storage import runtime
from armorrasp.core.transform.monkeypatch import patch
from armorrasp.engine.wrapper.wsgi_input_preview import WSGIInputWrapper
from armorrasp.config import logger_config


logger = logger_config("flask_middleware")


def do_patch(queue):
    """Do Flask do_patch"""
    try:
        import flask
        from flask import _request_ctx_stack
    except ImportError:
        logger.warning("No module named flask")
        return

    try:
        @patch(flask.app.Flask, "full_dispatch_request")
        def _call_request(orig, flask_self, *args, **kwargs):
            """Do Flask _call_request"""
            reqctx = _request_ctx_stack.top
            if reqctx is not None:
                runtime.memory_request(BasisFlaskRequest(reqctx.request))
            return orig(flask_self, *args, **kwargs)

        logger.info('hook Flask.full_dispatch_request sucess')
    except Exception as err:
        logger.error('hook Flask.__call__ failed %s' % err)

    try:
        @patch(flask.Flask, "__call__")
        def _wsgi_input_hook(orig, wsgi_self, *args, **kwargs):
            """Do Flask _wsgi_input_hook"""
            environ = args[0]
            wsgi_input = environ.get("wsgi.input")
            current_request = runtime.get_latest_request()
            if wsgi_input is not None and current_request is not None \
                    and not isinstance(wsgi_input, WSGIInputWrapper):
                input_wrapper = \
                    WSGIInputWrapper(wsgi_input,
                                     current_request.content_length, 4096)
                environ["wsgi.input"] = input_wrapper

            return orig(wsgi_self, *args, **kwargs)

        logger.info('hook Flask.full_dispatch_request sucess')
    except Exception as err:
        logger.error('hook Flask.__call__ failed %s' % err)
