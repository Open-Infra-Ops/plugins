""" constants
"""
ENABLE = True
BACKEND_URL = "http://raspx.his-beta.huawei.com/agent_server"
TENANT_ID = "00000000000000000000000000000000"
AGENT_ID = "0"
HEARTBEAT_INTERVAL = 60
