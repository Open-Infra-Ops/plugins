"""Do utils init work"""
