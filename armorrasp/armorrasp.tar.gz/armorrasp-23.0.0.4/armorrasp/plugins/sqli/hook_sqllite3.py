"""Do hook_sqllite3"""
from armorrasp.config import CONFIG
from armorrasp.core.transform.monkeypatch import patch
from armorrasp.plugins.sqli import sqli_detect
from armorrasp.config import logger_config

logger = logger_config("hook_sqllite3")


def do_patch(queue):
    """Do hook_sqllite3 do_patch"""
    try:
        import sqlite3
    except ImportError:
        logger.warning("No module named sqlite3")
        return
    try:
        @patch(sqlite3.Cursor, 'execute', block=False,
               report_name="plugin.python.sqlite3")
        def _rasp_execute(orig_execute, *args, **kwargs):
            """Do Cursor_execute _rasp_execute"""
            if CONFIG["SQLI_ENABLE"]:
                sqli_detect.SQLI.detect(queue, *args, **kwargs)
            return orig_execute(*args, **kwargs)
    except Exception as err:
        logger.error("hook sqlite3 failed, %s" % err)

    try:
        @patch(sqlite3.Cursor, 'executemany', block=False,
               report_name="plugin.python.sqlite3")
        def _rasp_executemany(orig_execute, *args, **kwargs):
            """Do Cursor_executemany _rasp_executemany"""
            if CONFIG["SQLI_ENABLE"]:
                sqli_detect.SQLI.detect(queue, *args, **kwargs)
            return orig_execute(*args, **kwargs)
    except Exception as err:
        logger.error("hook sqlite3 failed, %s" % err)
