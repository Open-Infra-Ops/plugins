"""Do wrapper init work"""
