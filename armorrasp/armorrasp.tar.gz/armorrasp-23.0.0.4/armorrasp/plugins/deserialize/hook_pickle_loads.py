"""Do hook_pickle_loads"""
from armorrasp.config import CONFIG
from armorrasp.core.transform.monkeypatch import patch
from armorrasp.plugins.deserialize import deserialize_check
from armorrasp.plugins.deserialize.deserialize_handler import \
    deserialize_handler
from armorrasp.config import logger_config

logger = logger_config("hook_pickle_loads")


def do_patch(queue):
    """Do hook_pickle_loads do_patch"""
    try:
        import pickle
    except ImportError:
        logger.warning("No module named pickle")
        return
    try:
        @patch(pickle, 'loads', block=False,
               report_name="plugin.python.deserialize.pickle")
        def _our_pickle_loads(orig_pickle_loads, *args, **kwargs):
            """Do pickle_loads _our_pickle_loads"""
            if CONFIG["DESERIALIZATION_ENABLE"]:
                check_params = \
                    deserialize_handler("ARG_0,KWARG:data", *args, **kwargs)
                for check_param in check_params:
                    deserialize_check.UntrustedDeserialize. \
                        deserialize_detect(queue, "pickle", check_param)
            return orig_pickle_loads(*args, **kwargs)
        logger.info("hook pickle.loads success")
    except Exception as err:
        logger.error("hook pickle._loads failed, %s" % err)

    try:
        @patch(pickle, 'load', block=False,
               report_name="plugin.python.deserialize.pickle")
        def _our_pickle_loads(orig_pickle_loads, *args, **kwargs):
            """Do pickle_load _our_pickle_loads"""
            if CONFIG["DESERIALIZATION_ENABLE"]:
                check_params = \
                    deserialize_handler("ARG_0,KWARG:file", *args, **kwargs)
                for check_param in check_params:
                    deserialize_check.UntrustedDeserialize. \
                        deserialize_detect(queue, "pickle", check_param)
            return orig_pickle_loads(*args, **kwargs)
        logger.info("hook pickle.load success")
    except Exception as err:
        logger.error("hook pickle._load failed, %s" % err)
