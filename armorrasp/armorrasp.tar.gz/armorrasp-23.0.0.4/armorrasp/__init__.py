"""Do init work"""
from .__about__ import __version__
from .armor import start

__all__ = [
    "__version__",
    "start",

]

