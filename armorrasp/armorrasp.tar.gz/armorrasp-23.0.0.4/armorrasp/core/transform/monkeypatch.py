"""Do monkeypatch"""
import ctypes

from armorrasp.config import logger_config

PY_SSIZE_T = hasattr(ctypes.pythonapi, 'Py_InitModule4_64') \
             and ctypes.c_int64 or ctypes.c_int

logger = logger_config("alarm_consumer")


class PyObject(ctypes.Structure):
    """Do PyObject"""
    pass


PyObject._fields_ = [('ob_refcnt', PY_SSIZE_T),
                     ('ob_type', ctypes.POINTER(PyObject))]


class DictProxy(PyObject):
    """Do DictProxy"""
    _fields_ = [('dict', ctypes.POINTER(PyObject))]


def patch_builtin(klass):
    """Do patch_builtin"""
    name = klass.__name__
    target = klass.__dict__
    proxy_dict = DictProxy.from_address(id(target))
    namespace = {}
    ctypes.pythonapi.PyDict_SetItem(
        ctypes.py_object(namespace),
        ctypes.py_object(name),
        proxy_dict.dict,
    )
    return namespace[name]


# monkeypatch 这里还有需要做的避免重复打点，去除hook功能，解析base，分开生成器函数和普通函数
def patch(base, target=None, block=False, timer=None, report_name=None,
          skip_if=None):
    """Do patch"""

    def wrapper(wrapped):
        """Do wrapper"""
        original = getattr(base, target)
        import functools

        @functools.wraps(original)
        def new_wrapped(*args, **kwargs):
            """Do patch new_wrapped"""
            return wrapped(original, *args, **kwargs)
        try:
            setattr(base, target, new_wrapped)
            logger.info("hook success, %s" % base)
        except Exception as err:
            patch_b = patch_builtin(base)
            patch_b[target] = new_wrapped
            logger.info("hook builtin success, %s" % base)
        return wrapped

    return wrapper
