#! /bin/sh
# chkconfig: 2345 55 25
# Description: SACC Service 
# Copyright (C) 2019 Huawei Technologies Co., Ltd.
### BEGIN INIT INFO
# Provides:saccservice
# Required-Start:
# Required-Stop:
# Should-Stop:
# Default-Start: 2 3 4 5
# Default-Stop: 0 1 6
# Description: Start the sacc service
### END INIT INFO

SACC_DIR=/usr/local/spes/Composites/Sacc
SACC_BIN=$SACC_DIR/saccservice
AUDITPLUGIN_BIN=$SACC_DIR/AuditSvc
AUDITPLUGIN_CONF=/etc/audisp/plugins.d/saccplugin.conf
AUDITPLUGIN_RULE=/etc/audit/rules.d/saccplugin.rules
CHKAPP_BIN=$SACC_DIR/tools/chkapp/chkapp
export LD_LIBRARY_PATH=$SACC_DIR/tools/chkapp:$LD_LIBRARY_PATH

EXIST=1
NOTEXIST=0
NOPID=0

procexists ()
{
  pidno=`ps -ef|grep -v "ps -ef"|grep -v grep|grep "$1"|awk '{print $2}'`
  if [ -z "$pidno" ]
  then
    return $NOTEXIST
  else
    return $EXIST
  fi
}

getpid ()
{
  pidno=`ps -ef|grep -v "ps -ef"|grep -v grep|grep "$1"|awk '{print $2}'`
  if [ -z "$pidno" ]
  then
    echo "$NOPID"
  else
    echo "$pidno"
  fi
}

startsacc()
{
  procexists $SACC_BIN
  if [ "$?" -eq "$NOTEXIST" ]
  then
    echo \ "Starting Sacc Service daemon "

    $SACC_BIN
	  sleep 1
    procexists "$SACC_BIN"
    if [ "$?" -eq "$NOTEXIST" ]
    then
      echo \ "Starting Sacc Service failed."
    fi
  else
    pid=`getpid $SACC_BIN`
    echo \ "Sacc Service($pid) is already running!"
  fi
}

stopproc()
{
  procexists $1
  if [ "$?" -ne "$NOTEXIST" ]; then
    pid=`getpid $1`
    if [ $pid -ne "0" ]; then
      kill -9 $pid
    fi
  fi
}

restart_auditd()
{
  service auditd stop > /dev/null 2>&1
  x=1
  while [ $x -le 10 ]
  do
    sleep 1
    procexists "audispd"
    if [ "$?" -eq "$NOTEXIST" ]; then
      break
    fi
    x=$(( $x + 1 ))
  done
  sleep 1
  service auditd start > /dev/null 2>&1
}

stop_audit_plugin()
{
  procexists $AUDITPLUGIN_BIN
  if [ "$?" -ne "$NOTEXIST" ]; then
    if [ -f $AUDITPLUGIN_CONF ]; then
      rm -f $AUDITPLUGIN_CONF > /dev/null 2>&1
      rm -f $AUDITPLUGIN_RULE > /dev/null 2>&1
      restart_auditd
    fi
  fi
}

stopsacc()
{
  #stop sacc
	procexists $SACC_BIN
  if [ "$?" -eq "$NOTEXIST" ]
  then
    echo \ "Sacc is not running! "
  else
    echo \ "Shutting down Sacc Service daemon..."
    pid=`getpid $SACC_BIN`
    kill -9 $pid
  fi

  stopproc $CHKAPP_BIN
  stop_audit_plugin
  for i in $(seq 1 5)
  do
    sleep 1
    procexists "$SACC_BIN"
    if [ "$?" -eq "$NOTEXIST" ]
    then
      break
    fi
  done
}

statussacc()
{
  procexists "$SACC_BIN"
  if [ "$?" -eq "$NOTEXIST" ]
  then
    echo \ "Sacc is not running!"
  else
    pid=`getpid $SACC_BIN`
    echo \ "Sacc Service($pid) is already running!"
  fi
}

version()
{
  cat $SACC_DIR/ClientVersion 
}

case "$1" in
  start)
    startsacc
    ;;
  stop)
    stopsacc
    ;;
  restart)
    stopsacc
    startsacc
    ;;
  status)
    statussacc
    ;;
  version)
    version
    ;;
  *)
    echo "Usage: $0 {start|stop|restart|status|version}"
    exit 1
    ;;
esac

