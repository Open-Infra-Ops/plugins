"""Do webshell_upload"""
from armorrasp.config import CONFIG
from armorrasp.core.runtime_info_storage import runtime
from armorrasp.info.record_attack import record_attack
from armorrasp.utils import pyrasp_exception
from armorrasp.config import logger_config
from armorrasp.utils.util import ensure_input_string
from armorrasp.utils.wrappor import exception_catch

logger = logger_config("webshell_upload")


class WebshellUpload:
    """Do WebshellUpload"""
    block = False

    @staticmethod
    @exception_catch("Failed to check webshell", return_value="")
    def detect_webshell(queue, *args, **kwargs):
        # 先看下request是否为空，如果为空则直接返回
        request = runtime.get_latest_request()
        if not request:
            return

        is_attack = False
        mess = ""
        sensitive_str = CONFIG["WEBSHELL_UPLOAD_BLACK"]
        param = ensure_input_string(args[1]).lower()
        for sen_str in sensitive_str:
            if sen_str in param:
                is_attack = True
                mess = \
                    'FileUpload - Detected dangerous method call {0} ' \
                    'in fileUpload query'.format(sen_str)
                break

        if not is_attack:
            return None
        if CONFIG["WEBSHELL_UPLOAD_BLOCK"]:
            record_attack(queue, "fileUpload", "block", mess,
                          params=args[1].lower(), request=request)
            raise pyrasp_exception.RaspSecurityException('fileUpload')
        record_attack(queue, "fileUpload", "log", mess,
                      params=args[1].lower(), request=request)
        return
