"""Do sqli_detect"""
from armorrasp.config import CONFIG
from armorrasp.core.runtime_info_storage import runtime
from armorrasp.info.record_attack import record_attack
from armorrasp.utils import pyrasp_exception
from armorrasp.config import logger_config
from armorrasp.utils.util import ensure_input_string
from armorrasp.utils.wrappor import exception_catch

logger = logger_config("sqli_detect")


class SQLI:
    """Do SQLI"""
    @staticmethod
    @exception_catch("Failed to check sqli", return_value="")
    def detect(queue, *args, **kwargs):
        # 先看下request是否为空，如果为空则直接返回
        request = runtime.get_latest_request()
        if not request:
            return

        is_attack = False
        query = ensure_input_string(args[1])
        mess = None
        # 用户匹配输入检测算法
        param_key, param_value = \
            request.check_user_input(query) or (None, None)
        if param_key and param_value:
            mess = \
                'SQLi - SQL query structure altered by user input, ' \
                'request parameter name: {0}, ' \
                'value is: {1}'.format(param_key, param_value)
            is_attack = True

        # 黑名单
        sensitive_str = CONFIG["SQLI_BLACK"]

        for sen_str in sensitive_str:
            if sen_str in query:
                is_attack = True
                mess = \
                    'SQLi - Detected dangerous method call {0} ' \
                    'in sql query'.format(sen_str)
                break

        if not is_attack:
            return None
        if CONFIG["SQLI_BLOCK"]:
            record_attack(queue, "sql", "block",
                          mess, params=query, request=request)
            raise pyrasp_exception.RaspSecurityException('SQLi')
        record_attack(queue, "sql", "log",
                      mess, params=query, request=request)
        return

