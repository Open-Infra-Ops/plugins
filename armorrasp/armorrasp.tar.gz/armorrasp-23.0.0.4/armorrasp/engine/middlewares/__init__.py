"""Do middlewares init work"""
