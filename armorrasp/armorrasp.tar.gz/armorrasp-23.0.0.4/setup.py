"""Do setup"""
from setuptools import setup

setup()
