"""about xArmor Python RASP"""
__author__ = "xArmor Python RASP"
__version__ = "23.0.0.4"
