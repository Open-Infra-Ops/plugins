#!/bin/sh
# to install client
unset LD_PRELOAD
. ./versioninfo.sh


if [ `whoami` != "root" ]
then
	echo "the current user is not root,please install with root !";
	exit;
fi

# print kernel information
KERNEL=`uname -r | awk -F '-' '{print $1}'`
echo "linux kernel: $KERNEL"

SUSE_VERSION=`cat /etc/*release|grep -iE 'suse.*10'`
if [ ! -z "$SUSE_VERSION" ]; then
	echo "not support SUSE 10"
	exit 1
fi

# check arch
if [ `arch` = "x86_64" ]; then
	BINDIR="bin-x64"
elif [ `arch` = "aarch64" ]; then
	BINDIR="ARM-x64"
else
	BINDIR="bin-x32"
fi

if [ ! -d "$BINDIR" ]; then
	echo "not support your system architecture"
	exit 1
fi

################################################################
# stop service
[ -f "/etc/init.d/saccserviced" ] && /etc/init.d/saccserviced stop
[ -f "/etc/init.d/servicemonitord" ] && /etc/init.d/servicemonitord stop
sleep 2

# remove old version
if [ -d "$CLIENT_INSTALL_PATH" ]; then
	rm -rf "$CLIENT_INSTALL_PATH"_bak
	mv -f $CLIENT_INSTALL_PATH "$CLIENT_INSTALL_PATH"_bak
	rm -rf "$CLIENT_INSTALL_PATH"_bak
fi

################################################################
# init directory
mkdir -p "$BASE_INSTALL_PATH"
mkdir -p "$BASE_INSTALL_PATH/temp"
mkdir -p "$CLIENT_INSTALL_PATH"
mkdir -p "$CLIENT_INSTALL_PATH/log"
mkdir -p "$CLIENT_INSTALL_PATH/cache"
mkdir -p "$CLIENT_INSTALL_PATH/policy"

echo "Bin dir is $BINDIR, begin copy..."
chmod 540 $BINDIR/*
if [ -f "$BINDIR/tools/chkapp/chkapp" ]; then
	chmod 540 "$BINDIR/tools/chkapp/chkapp"
fi
/bin/cp -rf "$BINDIR"/* "$CLIENT_INSTALL_PATH"
/bin/cp -f composite.configx "$CLIENT_INSTALL_PATH"/composite.configx

chown -R root $CLIENT_INSTALL_PATH  > /dev/null 2>&1
chgrp -R root $CLIENT_INSTALL_PATH > /dev/null 2>&1
chmod -R o-w $CLIENT_INSTALL_PATH > /dev/null 2>&1
chmod -R g-w $CLIENT_INSTALL_PATH > /dev/null 2>&1
chmod 540 "$CLIENT_INSTALL_PATH/saccservice"
chmod 540 "$CLIENT_INSTALL_PATH/servicemonitor"
chmod 750 "$CLIENT_INSTALL_PATH/AuditSvc"

if [ -f "${BASE_INSTALL_PATH}/temp/~svrpfsyslog-22.dax" ]; then
	rm "${BASE_INSTALL_PATH}/temp/~svrpfsyslog-22.dax"
fi

if [ -f "${BASE_INSTALL_PATH}/temp/~svrpfsyslog-12.dax" ]; then
	rm "${BASE_INSTALL_PATH}/temp/~svrpfsyslog-12.dax"
fi

if [ -f "${BASE_INSTALL_PATH}/temp/sacc/AppCreate.lua.unix.zip" ]; then
	rm "${BASE_INSTALL_PATH}/temp/sacc/AppCreate.lua.unix.zip"
else
	mkdir -p "${BASE_INSTALL_PATH}/temp/sacc/"
fi

if [ -f "${BASE_INSTALL_PATH}/temp/~svrpfsyslog-d2.dax" ]; then
	rm "${BASE_INSTALL_PATH}/temp/~svrpfsyslog-d2.dax"
fi

if [ -f "${BASE_INSTALL_PATH}/temp/luaupdatepkst.dax" ]; then
	rm "${BASE_INSTALL_PATH}/temp/luaupdatepkst.dax"
fi

if [ -f "./~svrpfsyslog-22.dax" ]; then
	/bin/cp -f ~svrpfsyslog-22.dax ${BASE_INSTALL_PATH}/temp/
	chmod 600 ${BASE_INSTALL_PATH}/temp/~svrpfsyslog-22.dax
fi

if [ -f "./~svrpfsyslog-12.dax" ]; then
	/bin/cp -f ~svrpfsyslog-12.dax ${BASE_INSTALL_PATH}/temp/
	chmod 600 ${BASE_INSTALL_PATH}/temp/~svrpfsyslog-12.dax
fi

if [ -f "./AppCreate.lua.unix.zip" ]; then
	/bin/cp -f AppCreate.lua.unix.zip ${BASE_INSTALL_PATH}/temp/sacc
	chmod 600 ${BASE_INSTALL_PATH}/temp/sacc/AppCreate.lua.unix.zip
fi

if [ -f "./~svrpfsyslog-d2.dax" ]; then
	/bin/cp -f ~svrpfsyslog-d2.dax ${BASE_INSTALL_PATH}/temp/
	chmod 600 ${BASE_INSTALL_PATH}/temp/~svrpfsyslog-d2.dax
fi

if [ -f "./luaupdatepkst.dax" ]; then
	/bin/cp -f luaupdatepkst.dax ${BASE_INSTALL_PATH}/temp/
	chmod 600 ${BASE_INSTALL_PATH}/temp/luaupdatepkst.dax
fi
################################################################
/bin/cp -f saccserviced.sh $CLIENT_INSTALL_PATH/
/bin/cp -f servicemonitord.sh $CLIENT_INSTALL_PATH/
chmod 540 $CLIENT_INSTALL_PATH/*.sh

# delete old shell
rm -f "/etc/init.d/saccserviced"
rm -f "/etc/init.d/servicemonitord"
echo "Set auto run..."
. ./setautorun.sh
setautorun $CLIENT_INSTALL_PATH/saccserviced.sh saccserviced saccserviced.service
setautorun $CLIENT_INSTALL_PATH/servicemonitord.sh servicemonitord servicemonitord.service
################################################################
if [ -f *"_Linux_"*".tar.gz" ]; then
	tar xzf *_Linux_*.tar.gz
	rm -f *_Linux_*.tar.gz
	cd *_Linux_*
	chmod 700 install.sh
	./install.sh
	cd ..
	rm -rf *_Linux_*
fi

# dump version info
touch "$CLIENT_INSTALL_PATH/ClientVersion"
echo $CLIENT_VERSION > "$CLIENT_INSTALL_PATH/ClientVersion"

# start
cd /
[ -f "/etc/init.d/saccserviced" ] && /etc/init.d/saccserviced start
[ -f "/etc/init.d/servicemonitord" ] && /etc/init.d/servicemonitord start
